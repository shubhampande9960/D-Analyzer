function resolve(url) {
	console.log('check');
	window.location.href = url;
}